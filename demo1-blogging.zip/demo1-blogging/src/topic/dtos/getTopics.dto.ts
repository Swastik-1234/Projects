// get-topic.dto.ts
export class GetTopicDto {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  createdAt: Date;
  updatedAt: Date;
}
