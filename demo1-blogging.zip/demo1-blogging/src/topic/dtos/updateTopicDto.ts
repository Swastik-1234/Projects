export class updateTopicDto {
    fieldToUpdate: string;
    newValue: string
}