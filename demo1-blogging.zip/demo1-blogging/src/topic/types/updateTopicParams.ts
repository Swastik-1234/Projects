export class updateTopicParams {
    fieldToUpdate: string;
    newValue: string
}