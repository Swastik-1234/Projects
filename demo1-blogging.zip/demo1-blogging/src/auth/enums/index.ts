export enum Role {
  VIEWER = 'VIEWER',
  ADMIN = 'ADMIN',
  SUPERADMIN = 'SUPERADMIN',
  EDITOR = 'EDITOR',
}
