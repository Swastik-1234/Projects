export const jwtConstants = {
  secret: 'think001001001001',
};
