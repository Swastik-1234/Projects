export class assignRoleDto {
  userId: string;
  userRole: string;
}
