export type createUserPasswordDetailsDto = {
  id: string;
  password: string;
};
