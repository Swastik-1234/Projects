export class createRoleDto {
  userId: string;
}
