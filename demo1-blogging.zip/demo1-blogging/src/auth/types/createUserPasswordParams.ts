export type createUserPasswordParams = {
  id: string;
  password: string;
};
