export class assignRoleParams {
  userId: string;
  userRole: string;
}
