export class editBlog {
    id?: string;
    name: string;
    desc: string;
    owner: string;
    header: string;
    footer: string;
    body: string;
    createdAt?: Date;
    updatedAt?: Date;
}
